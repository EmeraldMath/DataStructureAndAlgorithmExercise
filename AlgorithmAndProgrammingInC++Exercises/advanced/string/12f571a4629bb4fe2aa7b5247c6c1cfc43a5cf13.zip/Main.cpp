#include <bits/stdc++.h>
using namespace std;

// ================= 代码实现开始 =================

const int N = 500005;

/* 请在这里定义你需要的全局变量 */

// 计算str中有多少个回文子串
// 返回值：子串的数目
long long getAnswer(string str) {
    /* 请在这里设计你的算法 */
}

// ================= 代码实现结束 =================

char _s[N];

int main() {
    scanf("%s", _s + 1);
    printf("%lld\n", getAnswer(_s + 1));
    return 0;
}
